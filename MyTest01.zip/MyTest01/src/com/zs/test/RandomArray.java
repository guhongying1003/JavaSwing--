package com.zs.test;

import java.util.Random;

public class RandomArray {

    public static void main(String[] args) {

        // 打乱数组
        int[] arr = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15};
        // 生成随机数
        Random r = new Random();
        // 遍历数组打乱
        for (int i = 0; i < arr.length; i++) {
            int tempIndex = r.nextInt(arr.length);
            int temp = arr[i];
            arr[i] = arr[tempIndex];
            arr[tempIndex] = temp;
        }

        //打印一维数组
        for (int i : arr) {
            System.out.print(i + " ");
        }
        System.out.println();

        // 将打乱的数组添加到二维数组中
        int[][] data = new int[4][4];
        // 方法一: 遍历一维数组, 添加到二维数组中
        for (int i = 0; i < arr.length; i++) {
            data[i / 4][i % 4] = arr[i];
        }

        // 方法二: 遍历二维数组
        /*for (int i = 0; i < data.length; i++) {
            for (int j = 0; j < data[i].length; j++) {
                data[i][j] = arr[i * 4 + j];
            }
        }*/
        // 打印二维数组
        for (int i = 0; i < data.length; i++) {
            for (int j = 0; j < data[i].length; j++) {
                System.out.print(data[i][j] + " ");
            }
            System.out.println();
        }

    }

}
