package com.zs.ui;

import com.zs.bean.User;
import com.zs.util.CodeUtil;

import javax.swing.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;

public class LoginJFrame extends JFrame implements MouseListener, KeyListener {

    static List<User> list = new ArrayList<>();

    static {
        list.add(new User("zhangsan", "123"));
        list.add(new User("admin", "123"));
    }

    // 登录按钮
    JButton login = new JButton();
    // 注册按钮
    JButton register = new JButton();
    // 正确验证码
    JLabel rightCode = new JLabel();
    // 输入的验证码
    JTextField codeText = new JTextField();
    // 用户名
    JTextField usernameText = new JTextField();
    // 密码
    JPasswordField passwordText = new JPasswordField();

    // 初始化组件
    public LoginJFrame() {
        // 初始化界面
        initJFrame();

        // 初始化组件
        initView();

        // 设置可见
        this.setVisible(true);
    }

    private void initView() {
        // 添加用户名图片
        JLabel usernameImage = new JLabel(new ImageIcon("MyTest01\\image\\login\\用户名.png"));
        usernameImage.setBounds(116, 135, 47, 17);
        this.getContentPane().add(usernameImage);

        // 设置用户名输入框
        usernameText.setBounds(195, 134, 200, 30);
        this.getContentPane().add(usernameText);

        // 添加密码图片
        JLabel passwordImage = new JLabel(new ImageIcon("MyTest01\\image\\login\\密码.png"));
        passwordImage.setBounds(130, 195, 32, 16);
        this.getContentPane().add(passwordImage);

        // 设置密码输入框
        passwordText.setBounds(195, 195, 200, 30);
        this.getContentPane().add(passwordText);

        // 验证码文字图片
        JLabel codeImage = new JLabel(new ImageIcon("MyTest01\\image\\login\\验证码.png"));
        codeImage.setBounds(115, 256, 50, 30);
        this.getContentPane().add(codeImage);

        // 验证码输入框设置
        codeText.setBounds(195, 256, 100, 30);
        this.getContentPane().add(codeText);

        // 生成验证码
        String codeStr = CodeUtil.getCode();
        // 显示验证码
        rightCode.setText(codeStr);
        // 设置位置大小
        rightCode.setBounds(300, 256, 50, 30);
        // 点击更换验证码,添加点击事件
        rightCode.addMouseListener(this);
        this.getContentPane().add(rightCode);


        // 设置登录按钮
        login.setBounds(123, 310, 128, 47);
        login.setIcon(new ImageIcon("MyTest01\\image\\login\\登录按钮.png"));
        // 去除按钮默认边框
        login.setBorderPainted(false);
        // 去除按钮默认背景
        login.setContentAreaFilled(false);
        // 给登录按钮添加点击事件
        login.addMouseListener(this);
        this.getContentPane().add(login);

        // 设置注册按钮
        register.setBounds(256, 310, 128, 47);
        register.setIcon(new ImageIcon("MyTest01\\image\\login\\注册按钮.png"));
        // 去除按钮默认边框
        register.setBorderPainted(false);
        // 去除按钮默认背景
        register.setContentAreaFilled(false);
        // 给注册按钮添加点击事件
        register.addMouseListener(this);
        this.getContentPane().add(register);

        // 添加背景图片
        JLabel background = new JLabel(new ImageIcon("MyTest01\\image\\login\\background.png"));
        background.setBounds(0, 0, 470, 390);
        this.getContentPane().add(background);

        // 给文本框添加键盘监听事件
        usernameText.addKeyListener(this);
        passwordText.addKeyListener(this);
        codeText.addKeyListener(this);

    }

    private void initJFrame() {

        this.setTitle("登录注册界面");
        this.setSize(488, 430);
        // 设置关闭模式
        this.setDefaultCloseOperation(3);
        // 设置居中
        this.setLocationRelativeTo(null);
        // 置顶
        this.setAlwaysOnTop(true);
        // 取消默认布局
        this.setLayout(null);
        // 给全局添加键盘监听
        // this.addKeyListener(this);

    }

    // 提醒弹框
    private void showJDialog(String content) {
        // 创建一个弹窗对象
        JDialog jDialog = new JDialog();
        // 设置弹框大小
        jDialog.setSize(200, 150);
        // 让弹框置顶
        jDialog.setAlwaysOnTop(true);
        // 居中
        jDialog.setLocationRelativeTo(null);
        // 弹框不关闭,无法继续操作
        jDialog.setModal(true);

        // 创建JLabel对象管理文字,并添加到弹框中
        JLabel warning = new JLabel(content);
        warning.setBounds(0, 0, 200, 150);
        jDialog.getContentPane().add(warning);

        // 显示弹框
        jDialog.setVisible(true);
    }


    // 在组件上单击（按下并释放）鼠标按钮时调用。
    @Override
    public void mouseClicked(MouseEvent e) {
        System.out.println("鼠标按下并释放");
        if (e.getSource() == rightCode) {
            // 生成新的验证码
            String code = CodeUtil.getCode();
            rightCode.setText(code);
        } else if (e.getSource() == login) {
            // 点击登录按钮, 验证登录逻辑
            // 获取用户名,密码,验证码
            // 如果没有输入则为空串
            String username = usernameText.getText();
            String password = new String(passwordText.getPassword());
            String code = codeText.getText();
            User user = new User(username, password);

            // 先判断验证码
            if (code.length() == 0) {
                showJDialog("验证码不能为空");
                return;
            }
            // 再判断用户名和密码
            if (username.length() == 0 || password.length() == 0) {
                showJDialog("用户名或密码为空");
                return;
            }
            if (!rightCode.getText().equalsIgnoreCase(code)) {
                showJDialog("验证码错误");
                return;
            }
            if (contains(user)) {
                // 关闭登录界面,打开游戏界面
                this.setVisible(false);
                new GameJFrame();
            } else {
                showJDialog("用户名或密码错误");
                return;
            }

        }
    }

    // 在组件上按下鼠标按钮时调用。
    @Override
    public void mousePressed(MouseEvent e) {
        if (e.getSource() == login) {
            // 切换登录按钮背景图片
            login.setIcon(new ImageIcon("MyTest01\\image\\login\\登录按下.png"));
        } else if (e.getSource() == register) {
            // 切换注册按钮背景图片
            register.setIcon(new ImageIcon("MyTest01\\image\\login\\注册按下.png"));
        }
    }

    // 在组件上释放鼠标按钮时调用
    @Override
    public void mouseReleased(MouseEvent e) {
        if (e.getSource() == login) {
            login.setIcon(new ImageIcon("MyTest01\\image\\login\\登录按钮.png"));
        } else if (e.getSource() == register) {
            register.setIcon(new ImageIcon("MyTest01\\image\\login\\注册按钮.png"));
        }
    }

    // 当鼠标进入组件时调用。
    @Override
    public void mouseEntered(MouseEvent e) {

    }

    // 当鼠标退出组件时调用。
    @Override
    public void mouseExited(MouseEvent e) {

    }

    // 判断用户是否存在
    private boolean contains(User user) {
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getUsername().equals(user.getUsername()) && list.get(i).getPassword().equals(user.getPassword())) {
                return true;
            }
        }
        return false;
    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {
    }

    // 按钮事件
    @Override
    public void keyReleased(KeyEvent e) {
        // 默认回车键为登录
        // 如果按的事Enter键,则登录
        if (e.getKeyCode() == 10) {
            // 登录逻辑
            String username = usernameText.getText();
            String password = new String(passwordText.getPassword());
            String code = codeText.getText();
            User user = new User(username, password);

            // 先判断验证码
            if (code.length() == 0) {
                showJDialog("验证码不能为空");
                return;
            }
            // 再判断用户名和密码
            if (username.length() == 0 || password.length() == 0) {
                showJDialog("用户名或密码为空");
                return;
            }
            if (!rightCode.getText().equalsIgnoreCase(code)) {
                showJDialog("验证码错误");
                return;
            }
            if (contains(user)) {
                // 关闭登录界面,打开游戏界面
                this.setVisible(false);
                new GameJFrame();
            } else {
                showJDialog("用户名或密码错误");
                return;
            }
        }

    }

}
