package com.zs.ui;

import javax.swing.*;
import javax.swing.border.BevelBorder;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Random;

/*
 * 主界面
 */
public class GameJFrame extends JFrame implements KeyListener, ActionListener {

    // 创建二维数组, 存放打乱的数据
    int[][] data = new int[4][4];

    // 记录空白页0的位置
    int x = 0;
    int y = 0;

    // 记录图片路径
    String path = "MyTest01\\image\\animal\\animal3\\";

    // 定义正确二维数组
    int[][] win = new int[][]{
            {1, 2, 3, 4},
            {5, 6, 7, 8},
            {9, 10, 11, 12},
            {13, 14, 15, 0}
    };

    // 定义步数
    int step = 0;

    JMenuItem replayItem = new JMenuItem("重新游戏");
    JMenuItem reLoginItem = new JMenuItem("重新登录");
    JMenuItem closeItem = new JMenuItem("关闭游戏");
    JMenuItem accountItem = new JMenuItem("公众号");

    JMenuItem girlsItem = new JMenuItem("美女");
    JMenuItem animalsItem = new JMenuItem("动物");
    JMenuItem sportItem = new JMenuItem("运动");

    // 构造方法初始化界面参数
    public GameJFrame() {
        // 初始化界面
        initJFrame();

        // 初始化菜单
        initJMenuBar();

        // 初始化数据,打乱图片
        initData();

        // 初始化图片
        initImage();

        // 设置可见 写在最后
        this.setVisible(true);
    }

    private void initData() {
        // 打乱数组
        int[] arr = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15};
        // 生成随机数
        Random r = new Random();
        // 遍历数组打乱
        for (int i = 0; i < arr.length; i++) {
            int tempIndex = r.nextInt(arr.length);
            int temp = arr[i];
            arr[i] = arr[tempIndex];
            arr[tempIndex] = temp;
        }

        // 将打乱的数组添加到二维数组中
        // 方法一: 遍历一维数组, 添加到二维数组中
        for (int i = 0; i < arr.length; i++) {
            // 找到空白页0,坐标赋值给x,y
            if (arr[i] == 0) {
                x = i / 4;
                y = i % 4;
            }
            data[i / 4][i % 4] = arr[i];
        }
    }

    private void initImage() {
        // 清空所有图片
        this.getContentPane().removeAll();

        // 判断是否胜利
        if (victory()) {
            // 显示胜利图片
            JLabel winJLabel = new JLabel(new ImageIcon("D:\\WorkSpace\\MyProject02\\MyTest01\\image\\win.png"));
            winJLabel.setBounds(203, 283, 197, 73);
            this.getContentPane().add(winJLabel);
        }

        // 显示步数图片
        JLabel stepJLabel = new JLabel("步数: " + step);
        stepJLabel.setBounds(50, 30, 100, 20);
        this.getContentPane().add(stepJLabel);

        // 相对路径: 相对当前项目而言
        // 创建ImageIcon对象
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                // 获取图片序号,从打乱的二维数组中
                int number = data[i][j];
                // 创建JLabel对象,管理容器,管理图片
                JLabel jLabel = new JLabel(new ImageIcon(path + number + ".jpg"));
                // 指定图片位置
                jLabel.setBounds(105 * j + 83, 105 * i + 134, 105, 105);
                // 给图片添加边框
                jLabel.setBorder(new BevelBorder(1));
                // 把JLabel添加到界面中
                //this.add(jLabel);
                this.getContentPane().add(jLabel);
            }
        }
        // 注意: 先添加的图片在上方,后添加的图片在下面
        // 添加背景图片
        JLabel jLabel = new JLabel(new ImageIcon("MyTest01\\image\\background.png"));
        jLabel.setBounds(40, 40, 508, 560);
        // 添加到容器
        this.getContentPane().add(jLabel);

        // 刷新图片
        this.getContentPane().repaint();
    }

    private void initJMenuBar() {
        // 创建整个菜单对象
        JMenuBar jMenuBar = new JMenuBar();

        // 创建菜单上的两个选项对象 (功能, 关于我们)
        JMenu functionJMenu = new JMenu("功能");
        JMenu aboutJMenu = new JMenu("关于我们");
        JMenu changeImage = new JMenu("更换图片");
        // 创建选项下面条目对象
        // 功能: 重新游戏,重新登录,关闭游戏
        // 关于我们: 公众号


        changeImage.add(girlsItem);
        changeImage.add(animalsItem);
        changeImage.add(sportItem);

        // 添加条目到选项中
        functionJMenu.add(changeImage);
        functionJMenu.add(replayItem);
        functionJMenu.add(reLoginItem);
        functionJMenu.add(closeItem);

        aboutJMenu.add(accountItem);

        // 添加选项到菜单中
        jMenuBar.add(functionJMenu);
        jMenuBar.add(aboutJMenu);

        // 给条目添加点击监听事件
        replayItem.addActionListener(this);
        reLoginItem.addActionListener(this);
        closeItem.addActionListener(this);
        accountItem.addActionListener(this);

        girlsItem.addActionListener(this);
        animalsItem.addActionListener(this);
        sportItem.addActionListener(this);

        // 给界面添加菜单
        this.setJMenuBar(jMenuBar);
    }

    private void initJFrame() {
        // 设置宽高
        this.setSize(603, 680);
        // 设置标题
        this.setTitle("游戏主界面");
        // 设置置顶
        this.setAlwaysOnTop(true);
        // 设置居中 GameJFrame屏幕居中
        this.setLocationRelativeTo(null);
        // 设置关闭 3
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        // 取消默认布局, 取消组件居中, 也就是自定义图片位置
        this.setLayout(null);
        // 给全局添加键盘监听
        this.addKeyListener(this);
    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    // 按下不松时会调用此方法
    // 查看完整图片
    @Override
    public void keyPressed(KeyEvent e) {
        // 如果胜利,则不能查看完整图片
        if (victory()) {
            return;
        }

        int code = e.getKeyCode();
        if (code == 65) {
            // 把界面中所有图片全部删除
            this.getContentPane().removeAll();
            // 加载完整图片
            JLabel all = new JLabel(new ImageIcon(path + "all.jpg"));
            all.setBounds(83, 134, 420, 420);
            this.getContentPane().add(all);

            // 添加背景图片
            // 添加背景图片
            JLabel jLabel = new JLabel(new ImageIcon("MyTest01\\image\\background.png"));
            jLabel.setBounds(40, 40, 508, 560);
            // 添加到容器
            this.getContentPane().add(jLabel);
            // 刷新图片
            this.getContentPane().repaint();
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        // 如果胜利,则不能继续移动
        if (victory()) {
            return;
        }

        // 左37 上38 右39 下40
        int code = e.getKeyCode();
        System.out.println(code);
        if (code == 37) {
            // System.out.println("左");
            if (y == 3) {
                return;
            }

            data[x][y] = data[x][y + 1];
            data[x][y + 1] = 0;
            y++;
            step++;
            initImage();

        } else if (code == 38) {
            // System.out.println("上");
            if (x == 3) {
                return;
            }
            // 把空白块下方的数字往上移动
            // x,y  表示空白方块
            // x+1,y   表示空白方块下方的数字
            // 交换
            data[x][y] = data[x + 1][y];
            data[x + 1][y] = 0;
            x++;
            step++;
            // 按照最新的数字加载图片
            initImage();
        } else if (code == 39) {
            if (y == 0) {
                return;
            }
            // System.out.println("右");
            data[x][y] = data[x][y - 1];
            data[x][y - 1] = 0;
            y--;
            step++;
            initImage();

        } else if (code == 40) {
            if (x == 0) {
                return;
            }
            // System.out.println("下");
            data[x][y] = data[x - 1][y];
            data[x - 1][y] = 0;
            x--;
            step++;
            initImage();
        } else if (code == 65) {
            // 查看完成后,加载原来的图片
            initImage();
        } else if (code == 87) {
            // 一键通关
            data = new int[][]{
                    {1, 2, 3, 4},
                    {5, 6, 7, 8},
                    {9, 10, 11, 12},
                    {13, 14, 15, 0}
            };
            initImage();
        }
    }

    // 判断是否通关
    private boolean victory() {
        for (int i = 0; i < data.length; i++) {
            for (int j = 0; j < data[i].length; j++) {
                if (data[i][j] != win[i][j]) {
                    return false;
                }
            }
        }
        return true;
    }

    // 条目点击事件
    @Override
    public void actionPerformed(ActionEvent e) {
        Object obj = e.getSource();
        if (obj == replayItem) {
            System.out.println("重新游戏");
            // 步数清零,这个操作要在重新加载图片前
            step = 0;
            // 打乱数组
            initData();
            // 重新加载图片
            initImage();
        } else if (obj == reLoginItem) {
            System.out.println("重新登录");
            // 关闭当前界面
            this.setVisible(false);
            // 打开登录界面
            new LoginJFrame();
        } else if (obj == closeItem) {
            System.out.println("关闭游戏");
            System.exit(0);
        } else if (obj == accountItem) {
            System.out.println("公众号");

            // 创建弹框对象
            JDialog jDialog = new JDialog();
            // 创建一个JLabel管理图片
            JLabel jLabel = new JLabel(new ImageIcon("MyTest01\\image\\about.png"));
            // 设置大小
            jLabel.setBounds(0, 0, 258, 258);
            // 把图片添加到弹框
            jDialog.add(jLabel);
            // 设置弹框大小
            jDialog.setSize(344, 344);
            // 弹框置顶
            jDialog.setAlwaysOnTop(true);
            // 弹框居中
            jDialog.setLocationRelativeTo(null);
            // 弹框不关闭,无法继续操作
            jDialog.setModal(true);
            // 让弹框显示出来
            jDialog.setVisible(true);

        } else if (obj == girlsItem) {
            Random r = new Random();
            int index = r.nextInt(13) + 1;
            path = "MyTest01\\image\\girl\\girl" + index + "\\";

            // 步数清零,这个操作要在重新加载图片前
            step = 0;
            // 打乱数组
            initData();
            // 重新加载图片
            initImage();

        } else if (obj == animalsItem) {
            Random r = new Random();
            int index = r.nextInt(8) + 1;
            path = "MyTest01\\image\\animal\\animal" + index + "\\";

            // 步数清零,这个操作要在重新加载图片前
            step = 0;
            // 打乱数组
            initData();
            // 重新加载图片
            initImage();

        } else if (obj == sportItem) {
            Random r = new Random();
            int index = r.nextInt(10) + 1;
            path = "MyTest01\\image\\sport\\sport" + index + "\\";

            // 步数清零,这个操作要在重新加载图片前
            step = 0;
            // 打乱数组
            initData();
            // 重新加载图片
            initImage();

        }
    }
}
