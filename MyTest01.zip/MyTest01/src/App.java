import com.zs.ui.LoginJFrame;

public class App {

    public static void main(String[] args) {
        // 程序入口
        //new GameJFrame();
        new LoginJFrame();
    }

}
